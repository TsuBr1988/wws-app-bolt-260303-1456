import React, { useState, memo, useMemo, useCallback, useEffect } from 'react';
import { Plus, Filter, DollarSign, Calendar, TrendingUp, User, Search, ArrowUpDown, List, LayoutGrid, FileText } from 'lucide-react';
import { ChevronDown, Check } from 'lucide-react';
import { ProposalCard } from './ProposalCard';
import { ProposalForm } from './ProposalForm';
import { ProposalKanban } from './ProposalKanban';
import { ProposalDetails } from './ProposalDetails';
import { Proposal } from '../../types';
import { ProbabilityScores } from './ProbabilityModal';
import { useSupabaseQuery } from '../../hooks/useSupabase';
import { supabase } from '../../lib/supabase';
import { useSystemVersion } from '../../contexts/SystemVersionContext';
import { clearQueryCache } from '../../hooks/useSupabase';
import { formatCurrency } from '../../utils/formatCurrency';
import { useYear } from '../../contexts/YearContext';
import { useMonthlyGoals } from '../../hooks/useMonthlyGoals';

// Constante para status de propostas ativas
const ACTIVE_PROPOSAL_STATUSES = ['SQL', 'Proposta', 'Negociação', 'Análise de contrato'] as const;

const EMPRESA_OPTIONS = ['WWS', 'Worldwide', '2WS'] as const;

interface ProposalsProps {
  onDataChange?: () => void;
}

export const Proposals: React.FC<ProposalsProps> = memo(({ onDataChange }) => {
  const { selectedYear } = useYear();
  const { canEdit } = useSystemVersion();
  const canEditProposals = canEdit('proposals');
  const { getMonthGoal } = useMonthlyGoals();

  // Otimizar query com campos específicos
  const { data: proposalsData = [], loading, refetch } = useSupabaseQuery('proposals', {
    // Usar '*' para evitar quebrar a listagem se alguma coluna não existir neste projeto
    // (ex: coluna 'empresa' pode não existir em todos os ambientes)
    select: '*',
    orderBy: { column: 'created_at', ascending: false }
  });

  // Query separada para probability_scores apenas quando necessário
  const { data: probabilityData = [] } = useSupabaseQuery('probability_scores', {
    select: 'proposal_id, economic_buyer, metrics, decision_criteria, decision_process, identify_pain, champion, competition, engagement'
  });
  
  // Transform database data to match our Proposal interface
  const proposals: Proposal[] = useMemo(() => proposalsData.map(p => ({
    id: p.id,
    empresa: (p as any).empresa || undefined,
    client: p.client,
    monthlyValue: p.monthly_value,
    months: p.months,
    totalValue: p.total_value,
    status: p.status,
    commission: p.commission,
    commissionRate: p.commission_rate,
    closerId: p.closer_id || '',
    sdrId: p.sdr_id || undefined,
    margemPercentual: p.margem_percentual || undefined,
    cidade: p.cidade || undefined,
    familia: p.familia || undefined,
    closingDate: p.closing_date || undefined,
    lostDate: p.lost_date || undefined,
    lostReason: p.lost_reason || undefined,
    probabilityScores: (() => {
      const probData = probabilityData.find(pd => pd.proposal_id === p.id);
      return probData ? {
        economicBuyer: probData.economic_buyer,
        metrics: probData.metrics,
        decisionCriteria: probData.decision_criteria,
        decisionProcess: probData.decision_process,
        identifyPain: probData.identify_pain,
        champion: probData.champion,
        competition: probData.competition,
        engagement: probData.engagement
      } : undefined;
    })(),
    createdAt: p.created_at,
    updatedAt: p.updated_at
  })).filter(proposal => {
    // Filtrar propostas baseado no ano selecionado
    // Propostas em aberto (SQL/Proposta/Negociação/Análise de contrato) sempre são mostradas
    if (proposal.status === 'SQL' || proposal.status === 'Proposta' || proposal.status === 'Negociação' || proposal.status === 'Análise de contrato') {
      return true; // Sempre mostrar propostas em aberto
    }
    
    // Para propostas fechadas/perdidas, filtrar por ano
    if (proposal.status === 'Fechado' && proposal.closingDate) {
      return new Date(proposal.closingDate).getFullYear() === selectedYear;
    }
    
    if (proposal.status === 'Perdido' && proposal.lostDate) {
      return new Date(proposal.lostDate).getFullYear() === selectedYear;
    }
    
    // Fallback para data de criação se não houver data específica
    return new Date(proposal.createdAt).getFullYear() === selectedYear;
  }), [proposalsData, probabilityData, selectedYear]);

  const [filter, setFilter] = useState('all');
  const [empresaFilter, setEmpresaFilter] = useState<'all' | string>('all');
  const [selectedMonths, setSelectedMonths] = useState<string[]>(['all']);
  const [showMonthDropdown, setShowMonthDropdown] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState<'client' | 'created_at' | 'status' | 'monthly_value'>('created_at');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const [viewMode, setViewMode] = useState<'list' | 'kanban'>(() => {
    const saved = localStorage.getItem('proposalsViewMode');
    return (saved === 'kanban' || saved === 'list') ? saved : 'list';
  });
  const [selectedProposal, setSelectedProposal] = useState<Proposal | null>(null);
  const [showResumoModal, setShowResumoModal] = useState(false);

  // Filtros do modal de Resumo das Propostas
  const [resumoEmpresa, setResumoEmpresa] = useState<'all' | string>('all');
  const [resumoDataInicial, setResumoDataInicial] = useState<string>('');
  const [resumoDataFinal, setResumoDataFinal] = useState<string>('');
  const [resumoStatus, setResumoStatus] = useState<'all' | string>('all');
  const [resumoProbabilidade, setResumoProbabilidade] = useState<'all' | 'nao_avaliada' | 'baixa' | 'media' | 'alta'>('all');
  const [resumoValorMin, setResumoValorMin] = useState<string>('');
  const [resumoValorMax, setResumoValorMax] = useState<string>('');
  const [resumoMargemMin, setResumoMargemMin] = useState<string>('');
  const [resumoMargemMax, setResumoMargemMax] = useState<string>('');
  const [resumoCidade, setResumoCidade] = useState<'all' | string>('all');

  const getProbabilityKey = useCallback((proposal: Proposal) => {
    const totalScore = proposal.probabilityScores
      ? (
          proposal.probabilityScores.economicBuyer +
          proposal.probabilityScores.metrics +
          proposal.probabilityScores.decisionCriteria +
          proposal.probabilityScores.decisionProcess +
          proposal.probabilityScores.identifyPain +
          proposal.probabilityScores.champion +
          proposal.probabilityScores.competition +
          proposal.probabilityScores.engagement
        )
      : 0;

    if (totalScore <= 0) return 'nao_avaliada' as const;
    if (totalScore < 12) return 'baixa' as const;
    if (totalScore <= 18) return 'media' as const;
    return 'alta' as const;
  }, []);

  const resumoEmpresasDisponiveis = useMemo(() => {
    return [...EMPRESA_OPTIONS];
  }, []);

  const resumoCidadesDisponiveis = useMemo(() => {
    const cidades = new Set<string>();
    proposals.forEach(p => {
      if (p.cidade) cidades.add(String(p.cidade));
    });
    return Array.from(cidades).sort((a, b) => a.localeCompare(b, 'pt-BR'));
  }, [proposals]);

  const resumoPropostasFiltradas = useMemo(() => {
    const base = proposals.filter(p => ACTIVE_PROPOSAL_STATUSES.includes(p.status as any));

    const valorMin = resumoValorMin.trim() === '' ? null : Number(resumoValorMin);
    const valorMax = resumoValorMax.trim() === '' ? null : Number(resumoValorMax);
    const margemMin = resumoMargemMin.trim() === '' ? null : Number(resumoMargemMin);
    const margemMax = resumoMargemMax.trim() === '' ? null : Number(resumoMargemMax);

    const dataInicial = resumoDataInicial ? new Date(`${resumoDataInicial}T00:00:00.000`) : null;
    const dataFinal = resumoDataFinal ? new Date(`${resumoDataFinal}T23:59:59.999`) : null;

    return base
      .filter(p => {
        if (resumoEmpresa !== 'all' && (p.empresa || '') !== resumoEmpresa) return false;
        if (resumoStatus !== 'all' && p.status !== resumoStatus) return false;
        if (resumoCidade !== 'all' && (p.cidade || '') !== resumoCidade) return false;

        if (dataInicial || dataFinal) {
          const created = new Date(p.createdAt);
          if (dataInicial && created < dataInicial) return false;
          if (dataFinal && created > dataFinal) return false;
        }

        if (resumoProbabilidade !== 'all') {
          const key = getProbabilityKey(p);
          if (key !== resumoProbabilidade) return false;
        }

        if (valorMin !== null && !Number.isNaN(valorMin) && p.monthlyValue < valorMin) return false;
        if (valorMax !== null && !Number.isNaN(valorMax) && p.monthlyValue > valorMax) return false;

        if (margemMin !== null || margemMax !== null) {
          if (p.margemPercentual === undefined || p.margemPercentual === null) return false;
          if (margemMin !== null && !Number.isNaN(margemMin) && p.margemPercentual < margemMin) return false;
          if (margemMax !== null && !Number.isNaN(margemMax) && p.margemPercentual > margemMax) return false;
        }

        return true;
      })
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [
    proposals,
    resumoEmpresa,
    resumoStatus,
    resumoCidade,
    resumoDataInicial,
    resumoDataFinal,
    resumoProbabilidade,
    resumoValorMin,
    resumoValorMax,
    resumoMargemMin,
    resumoMargemMax,
    getProbabilityKey,
  ]);

  // Persist viewMode to localStorage
  useEffect(() => {
    localStorage.setItem('proposalsViewMode', viewMode);
  }, [viewMode]);

  // Generate available months from proposals
  const availableMonths = useMemo(() => {
    const months = new Set<string>();
    proposals.forEach(proposal => {
      const date = new Date(proposal.createdAt);
      const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      months.add(monthKey);
    });
    
    return Array.from(months).sort().reverse(); // Most recent first
  }, [proposals]);

  const formatMonthLabel = useCallback((monthKey: string) => {
    const [year, month] = monthKey.split('-');
    const date = new Date(parseInt(year), parseInt(month) - 1);
    return date.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });
  }, []);

  const handleMonthToggle = useCallback((monthKey: string) => {
    if (monthKey === 'all') {
      // Toggle all - se já tem todos selecionados, limpar; senão selecionar todos
      if (selectedMonths.includes('all') || selectedMonths.length === availableMonths.length) {
        setSelectedMonths([]);
      } else {
        setSelectedMonths(['all']);
      }
    } else {
      setSelectedMonths(prev => {
        // Remove 'all' se estiver presente
        let newSelection = prev.filter(m => m !== 'all');
        
        if (prev.includes(monthKey)) {
          // Remove o mês se já estiver selecionado
          newSelection = newSelection.filter(m => m !== monthKey);
        } else {
          // Adiciona o mês se não estiver selecionado
          newSelection = [...newSelection, monthKey];
        }
        
        // Se todos os meses estão selecionados, mostrar como 'all'
        if (newSelection.length === availableMonths.length) {
          return ['all'];
        }
        
        return newSelection;
      });
    }
  }, [availableMonths]);

  // Filter and search proposals
  const filteredProposals = useMemo(() => {
    let filtered = proposals.filter(proposal => {
      // Filter by status
      const statusMatch = filter === 'all' || proposal.status === filter;

      // Filter by empresa
      const empresaMatch = empresaFilter === 'all' || (proposal.empresa || '') === empresaFilter;
      
      // Filter by search term (client name - partial match, case insensitive)
      const searchMatch = searchTerm === '' || 
        proposal.client.toLowerCase().includes(searchTerm.toLowerCase());
      
      // Filter by month
      if (selectedMonths.includes('all') || selectedMonths.length === 0) {
        return statusMatch && empresaMatch && searchMatch;
      }
      
      const proposalDate = new Date(proposal.createdAt);
      const proposalMonthKey = `${proposalDate.getFullYear()}-${String(proposalDate.getMonth() + 1).padStart(2, '0')}`;
      const monthMatch = selectedMonths.includes(proposalMonthKey);
      
      return statusMatch && empresaMatch && searchMatch && monthMatch;
    });
    
    // Sort proposals
    return filtered.sort((a, b) => {
      let aValue: any, bValue: any;
      
      switch (sortBy) {
        case 'client':
          aValue = a.client.toLowerCase();
          bValue = b.client.toLowerCase();
          break;
        case 'created_at':
          aValue = new Date(a.createdAt).getTime();
          bValue = new Date(b.createdAt).getTime();
          break;
        case 'status':
          // Order: SQL, Proposta, Negociação, Análise de contrato, Fechado, Perdido
          const statusOrder = {
            'SQL': 1,
            'Proposta': 2,
            'Negociação': 3,
            'Análise de contrato': 4,
            'Fechado': 5,
            'Perdido': 6
          };
          aValue = statusOrder[a.status as keyof typeof statusOrder];
          bValue = statusOrder[b.status as keyof typeof statusOrder];
          break;
        case 'monthly_value':
          aValue = a.monthlyValue;
          bValue = b.monthlyValue;
          break;
        default:
          aValue = new Date(a.createdAt).getTime();
          bValue = new Date(b.createdAt).getTime();
      }
      
      if (sortOrder === 'asc') {
        return aValue > bValue ? 1 : aValue < bValue ? -1 : 0;
      } else {
        return aValue < bValue ? 1 : aValue > bValue ? -1 : 0;
      }
    });
  }, [proposals, filter, empresaFilter, searchTerm, selectedMonths, sortBy, sortOrder]);

  // Função para calcular meta efetiva de um mês considerando carry-over
  const calculateEffectiveMonthGoal = useCallback((month: number, year: number): number => {
    let carryOverFromPreviousMonth = 0;
    let effectiveGoalForRequestedMonth = 0;

    for (let m = 1; m <= month; m++) {
      const targetRevenueMonthly = getMonthGoal(m);
      const targetRevenue = targetRevenueMonthly * 12; // Anualizar para comparar com receita anualizada

      // Contratos fechados no mês
      const monthContracts = proposals.filter(p => {
        if (p.status !== 'Fechado' || !p.closingDate) return false;
        const closingDate = new Date(p.closingDate);
        return closingDate.getMonth() + 1 === m && closingDate.getFullYear() === year;
      });

      const actualRevenue = monthContracts.reduce(
        (sum, c) => sum + (c.monthlyValue * 12), 0
      );

      const effectiveTarget = Math.max(0, targetRevenue + carryOverFromPreviousMonth);

      // Se este é o mês solicitado, guardar a meta efetiva
      if (m === month) {
        effectiveGoalForRequestedMonth = effectiveTarget;
      }

      const realDeficit = Math.max(0, effectiveTarget - actualRevenue);
      const realSurplus = Math.max(0, actualRevenue - effectiveTarget);

      // Calcular carry-over para próximo mês
      if (targetRevenue > 0) {
        carryOverFromPreviousMonth = realSurplus > 0 ? -realSurplus : realDeficit;
      } else if (actualRevenue > 0) {
        carryOverFromPreviousMonth = -actualRevenue;
      }
    }

    // Retornar meta efetiva do mês solicitado (mensal, não anualizada)
    return effectiveGoalForRequestedMonth / 12; // Desanualizar para valor mensal
  }, [proposals, getMonthGoal]);

  // Calculate stats based on filtered proposals
  const stats = useMemo(() => {
    // Filtrar apenas propostas ativas usando a constante
    const activeProposals = proposals.filter(p =>
      ACTIVE_PROPOSAL_STATUSES.includes(p.status as any)
    );

    // Calcular valor total ANUALIZADO (valor mensal * 12)
    const totalValue = activeProposals.reduce((sum, p) => sum + (p.monthlyValue ), 0);

    // Obter mês e ano atuais
    const currentDate = new Date();
    const currentMonth = currentDate.getMonth() + 1;
    const currentYear = currentDate.getFullYear();
    const currentMonthStart = new Date(currentYear, currentMonth - 1, 1);
    const currentMonthEnd = new Date(currentYear, currentMonth, 0);

    // Calcular meta efetiva do mês atual considerando carry-over (anualizada)
    const effectiveMonthGoal = calculateEffectiveMonthGoal(currentMonth, currentYear) / 12;
    const pipelineCoverage = effectiveMonthGoal > 0
      ? (totalValue / effectiveMonthGoal) * 100
      : 0;

    // Calcular evolução de propostas ativas (mês atual vs anterior)
    const previousMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1);
    const previousMonthEnd = new Date(currentDate.getFullYear(), currentDate.getMonth(), 0);

    // Contar propostas ativas criadas no mês atual
    const currentMonthActiveCount = proposals.filter(proposal => {
      const createdDate = new Date(proposal.createdAt);
      const isActive = ACTIVE_PROPOSAL_STATUSES.includes(proposal.status as any);
      return isActive && createdDate >= currentMonth && createdDate <= currentMonthEnd;
    }).length;

    // Contar propostas ativas criadas no mês anterior
    const previousMonthActiveCount = proposals.filter(proposal => {
      const createdDate = new Date(proposal.createdAt);
      const isActive = ACTIVE_PROPOSAL_STATUSES.includes(proposal.status as any);
      return isActive && createdDate >= previousMonth && createdDate <= previousMonthEnd;
    }).length;

    // Calcular evolução percentual
    const proposalEvolution = previousMonthActiveCount > 0
      ? ((currentMonthActiveCount - previousMonthActiveCount) / previousMonthActiveCount) * 100
      : currentMonthActiveCount > 0 ? 100 : 0;

    // Filtrar propostas avaliadas APENAS das ativas (não fechadas nem perdidas)
    const evaluatedProposals = activeProposals
      .filter(p => p.probabilityScores);

    let averageProbability = 0;
    let averageProbabilityLabel = 'Não avaliada';

    if (evaluatedProposals.length > 0) {
      const totalScore = evaluatedProposals.reduce((sum, p) => {
        const scores = Object.values(p.probabilityScores!).reduce((s, score) => s + score, 0);
        return sum + scores;
      }, 0);

      const avgScore = totalScore / evaluatedProposals.length;
      averageProbability = Math.round((avgScore / 24) * 100);

      if (avgScore < 12) averageProbabilityLabel = 'Baixa';
      else if (avgScore <= 18) averageProbabilityLabel = 'Média';
      else averageProbabilityLabel = 'Alta';
    }

    return {
      totalValue,
      effectiveMonthGoal,
      pipelineCoverage,
      activeProposalsCount: activeProposals.length,
      proposalEvolution,
      averageProbability,
      averageProbabilityLabel,
      evaluatedCount: evaluatedProposals.length
    };
  }, [proposals, calculateEffectiveMonthGoal, selectedYear]);
  
  const handleAddProposal = useCallback((newProposal: Omit<Proposal, 'id' | 'createdAt' | 'updatedAt'>) => {
    const insertProposal = async () => {
      try {
        // Usar a data da proposta fornecida pelo usuário
        const proposalDate = new Date(newProposal.proposalDate).toISOString();
        
        const proposalData = {
          empresa: (newProposal as any).empresa || null,
          client: newProposal.client,
          monthly_value: newProposal.monthlyValue,
          months: newProposal.months,
          total_value: newProposal.totalValue,
          status: newProposal.status,
          commission: newProposal.commission,
          commission_rate: newProposal.commissionRate,
          closer_id: newProposal.closerId,
          sdr_id: newProposal.sdrId || null,
          familia: newProposal.familia || null,
          closing_date: newProposal.closingDate || null,
          lost_date: newProposal.lostDate || null,
          lost_reason: newProposal.lostReason || null,
          created_at: proposalDate,
          updated_at: proposalDate
        };

        console.log('Dados sendo inseridos no Supabase:', proposalData);

        let insertResult = await supabase
          .from('proposals')
          .insert(proposalData as any)
          .select()
          .single();

        if (insertResult.error) {
          const msg = String(insertResult.error.message || '');
          const isEmpresaColumnMissing =
            msg.toLowerCase().includes('empresa') &&
            (msg.toLowerCase().includes('schema cache') || msg.toLowerCase().includes('does not exist'));

          if (isEmpresaColumnMissing) {
            const { empresa: _empresa, ...proposalDataWithoutEmpresa } = proposalData as any;
            insertResult = await supabase
              .from('proposals')
              .insert(proposalDataWithoutEmpresa)
              .select()
              .single();
          }
        }

        if (insertResult.error) {
          console.error('Error inserting proposal:', insertResult.error);
          alert(`Erro ao criar proposta: ${insertResult.error.message}`);
          return;
        }

        console.log('Proposal created successfully:', insertResult.data);
        
        // Refresh the data
        await refetch();
        setShowForm(false);
      } catch (err) {
        console.error('Unexpected error:', err);
        alert('Erro inesperado ao criar proposta. Tente novamente.');
      }
    };

    insertProposal();
  }, [refetch]);

  const handleUpdateProbability = useCallback((proposalId: string, scores: ProbabilityScores) => {
    const updateScores = async () => {
      try {
        const totalScore = Object.values(scores).reduce((sum, score) => sum + score, 0);
        
        // Limpar cache antes de fazer a operação
        clearQueryCache('probability_scores');
        clearQueryCache('proposals');
        
        // Verificar se já existe um registro de probabilidade
        const { data: existingScore, error: checkError } = await supabase
          .from('probability_scores')
          .select('id')
          .eq('proposal_id', proposalId)
          .maybeSingle();

        if (checkError && checkError.code !== 'PGRST116') {
          throw checkError;
        }

        // Preparar dados para salvar no banco
        const scoreData = {
          economic_buyer: scores.economicBuyer,
          metrics: scores.metrics,
          decision_criteria: scores.decisionCriteria,
          decision_process: scores.decisionProcess,
          identify_pain: scores.identifyPain,
          champion: scores.champion,
          competition: scores.competition,
          engagement: scores.engagement,
          updated_at: new Date().toISOString()
        };

        let result;
        if (existingScore) {
          const { data, error } = await supabase
            .from('probability_scores')
            .update(scoreData)
            .eq('proposal_id', proposalId)
            .select()
            .single();
          
          result = { data, error };
        } else {
          const { data, error } = await supabase
            .from('probability_scores')
            .insert({
              proposal_id: proposalId,
              ...scoreData
            })
            .select()
            .single();
          
          result = { data, error };
        }

        if (result.error) {
          alert(`Erro ao atualizar probabilidade: ${result.error.message}`);
          return;
        }

        // Limpar cache após salvar
        clearQueryCache('probability_scores');
        clearQueryCache('proposals');
        
        // Forçar atualização completa dos dados
        await refetch();
        
        // Pequeno delay para garantir que os dados foram atualizados
        setTimeout(() => {
          window.location.reload();
        }, 500);
        
      } catch (err) {
        alert(`Erro inesperado ao atualizar probabilidade: ${err instanceof Error ? err.message : 'Tente novamente.'}`);
      }
    };

    updateScores();
  }, [refetch]);

  const handleUpdateProposal = useCallback((updatedProposal: Proposal) => {
    const updateProposal = async () => {
      try {
        console.log('Updating proposal:', updatedProposal.id, 'with data:', updatedProposal);
        
        const proposalData = {
          empresa: updatedProposal.empresa || null,
          client: updatedProposal.client,
          monthly_value: updatedProposal.monthlyValue,
          months: updatedProposal.months,
          total_value: updatedProposal.totalValue,
          status: updatedProposal.status,
          commission: updatedProposal.commission,
          commission_rate: updatedProposal.commissionRate,
          closer_id: updatedProposal.closerId,
          sdr_id: updatedProposal.sdrId || null,
          familia: updatedProposal.familia || null,
          closing_date: updatedProposal.closingDate || null,
          lost_date: updatedProposal.lostDate || null,
          lost_reason: updatedProposal.lostReason || null,
          updated_at: new Date().toISOString()
        };

        console.log('Sending to Supabase:', proposalData);
        
        let updateResult = await supabase
          .from('proposals')
          .update(proposalData as any)
          .eq('id', updatedProposal.id)
          .select()
          .single();

        if (updateResult.error) {
          const msg = String(updateResult.error.message || '');
          const isEmpresaColumnMissing =
            msg.toLowerCase().includes('empresa') &&
            (msg.toLowerCase().includes('schema cache') || msg.toLowerCase().includes('does not exist'));

          if (isEmpresaColumnMissing) {
            const { empresa: _empresa, ...proposalDataWithoutEmpresa } = proposalData as any;
            updateResult = await supabase
              .from('proposals')
              .update(proposalDataWithoutEmpresa)
              .eq('id', updatedProposal.id)
              .select()
              .single();
          }
        }

        if (updateResult.error) {
          console.error('Supabase update error:', updateResult.error);
          alert(`Erro ao atualizar proposta: ${updateResult.error.message}`);
          return;
        }
        
        console.log('Update successful:', updateResult.data);
        
        // Clear cache to force refresh
        clearQueryCache('proposals');
        clearQueryCache('probability_scores');

        // Force refresh of all data to update the entire system
        await refetch();
        if (onDataChange) onDataChange();
        
        // Small delay to ensure UI updates
        setTimeout(() => {
          console.log('Proposal update completed');
        }, 100);
        
      } catch (err) {
        console.error('Unexpected error updating proposal:', err);
        alert('Erro inesperado ao atualizar proposta.');
      }
    };

    updateProposal();
  }, [refetch, onDataChange]);

  const handleMoveProposal = useCallback((proposalId: string, newStatus: string) => {
    const proposal = proposals.find(p => p.id === proposalId);
    if (!proposal) return;

    const updatedProposal = { ...proposal, status: newStatus };
    handleUpdateProposal(updatedProposal);
  }, [proposals, handleUpdateProposal]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12 min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <div className="text-lg text-gray-700">Carregando Propostas...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Propostas {selectedYear}</h1>
          <p className="text-gray-600">
            Gerencie suas propostas e acompanhe comissões para {selectedYear}
            {(filter === 'SQL' || filter === 'Proposta' || filter === 'Negociação' || filter === 'all') &&
             ' (propostas em aberto de todos os anos)'}
          </p>
        </div>
        {canEditProposals ? (
          <button 
            onClick={() => setShowForm(true)}
            className="bg-green-600 text-white px-4 py-2 rounded-lg flex items-center space-x-2 hover:bg-green-700 transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Nova Proposta</span>
          </button>
        ) : (
          <div className="bg-gray-100 text-gray-500 px-4 py-2 rounded-lg flex items-center space-x-2">
            <Plus className="w-4 h-4" />
            <span>Modo Somente Leitura</span>
          </div>
        )}
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Valor Total</p>
              <p className="text-2xl font-bold text-gray-900">{formatCurrency(stats.totalValue)}</p>
            </div>
            <div className="w-12 h-12 rounded-lg bg-blue-500 flex items-center justify-center">
              <DollarSign className="w-6 h-6 text-white" />
            </div>
          </div>
          <p className="text-xs text-gray-500 mt-1">
            Status: SQL, Proposta, Negociação e Análise de contrato
          </p>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Cobertura do Pipeline</p>
              <div className="flex items-center space-x-2">
                <p className="text-2xl font-bold text-green-600">{stats.pipelineCoverage.toFixed(1)}%</p>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                  stats.pipelineCoverage >= 100
                    ? 'bg-green-100 text-green-800'
                    : stats.pipelineCoverage >= 50
                    ? 'bg-yellow-100 text-yellow-800'
                    : 'bg-red-100 text-red-800'
                }`}>
                  {stats.pipelineCoverage >= 100
                    ? 'Excelente'
                    : stats.pipelineCoverage >= 50
                    ? 'Atenção'
                    : 'Crítico'}
                </span>
              </div>
              <p className="text-xs text-gray-500 mt-1">
                {formatCurrency(stats.totalValue)} de {formatCurrency(stats.effectiveMonthGoal)} meta efetiva
              </p>
            </div>
            <div className="w-12 h-12 rounded-lg bg-green-500 flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Propostas Ativas</p>
              <div className="flex items-center space-x-2">
                <p className="text-2xl font-bold text-gray-900">{stats.activeProposalsCount}</p>
                {stats.proposalEvolution !== 0 && (
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    stats.proposalEvolution > 0 
                      ? 'bg-green-100 text-green-800' 
                      : 'bg-red-100 text-red-800'
                  }`}>
                    {stats.proposalEvolution > 0 ? '+' : ''}{stats.proposalEvolution.toFixed(1)}%
                  </span>
                )}
              </div>
              <p className="text-xs text-gray-500">
                {stats.proposalEvolution !== 0 && (
                  <>Evolução mês atual vs anterior • </>
                )}
                SQL, Proposta, Negociação e Análise
              </p>
            </div>
            <div className="w-12 h-12 rounded-lg bg-purple-500 flex items-center justify-center">
              <Calendar className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Avaliação Média</p>
              <div className="flex items-center space-x-2">
                <p className="text-2xl font-bold text-orange-600">{stats.averageProbability}%</p>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                  stats.averageProbabilityLabel === 'Alta' ? 'bg-green-100 text-green-800' :
                  stats.averageProbabilityLabel === 'Média' ? 'bg-yellow-100 text-yellow-800' :
                  stats.averageProbabilityLabel === 'Baixa' ? 'bg-red-100 text-red-800' :
                  'bg-gray-100 text-gray-800'
                }`}>
                  {stats.averageProbabilityLabel}
                </span>
              </div>
            </div>
            <div className="w-12 h-12 rounded-lg bg-orange-500 flex items-center justify-center">
              <User className="w-6 h-6 text-white" />
            </div>
          </div>
          <p className="text-xs text-gray-500 mt-1">
            Baseado em {stats.evaluatedCount} avaliações ativas
          </p>
        </div>
      </div>

      {/* Compact Filters - All in One Line */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 space-y-3">
        <div className="flex items-center gap-4 flex-wrap">
          {/* View Mode Toggle */}
          <div className="flex items-center gap-2">
            <span className="text-xs font-medium text-gray-600">Visualização:</span>
            <div className="flex items-center bg-gray-100 rounded-lg p-0.5">
              <button
                onClick={() => setViewMode('list')}
                className={`flex items-center gap-1 px-2 py-1 rounded transition-colors ${
                  viewMode === 'list'
                    ? 'bg-white text-blue-600 shadow-sm'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
                title="Visualização em lista"
              >
                <List className="w-3.5 h-3.5" />
                <span className="text-xs font-medium">Lista</span>
              </button>
              <button
                onClick={() => setViewMode('kanban')}
                className={`flex items-center gap-1 px-2 py-1 rounded transition-colors ${
                  viewMode === 'kanban'
                    ? 'bg-white text-blue-600 shadow-sm'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
                title="Visualização em colunas por etapa"
              >
                <LayoutGrid className="w-3.5 h-3.5" />
                <span className="text-xs font-medium">CRM</span>
              </button>
            </div>
          </div>

          <div className="h-6 w-px bg-gray-300"></div>

          {/* Search Bar */}
          <div className="flex-1 min-w-[200px] max-w-xs">
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 transform -translate-y-1/2 w-3.5 h-3.5 text-gray-400" />
              <input
                type="text"
                placeholder="Buscar por nome do cliente..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-8 pr-8 py-1.5 border border-gray-300 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-green-500 focus:border-green-500"
              />
              {searchTerm && (
                <button
                  onClick={() => setSearchTerm('')}
                  className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  ×
                </button>
              )}
            </div>
          </div>

          <div className="h-6 w-px bg-gray-300"></div>

          {/* Sort Controls */}
          <div className="flex items-center gap-2">
            <ArrowUpDown className="w-3.5 h-3.5 text-gray-500" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="px-2 py-1.5 border border-gray-300 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-green-500"
            >
              <option value="created_at">Data de Inclusão</option>
              <option value="client">Nome do Cliente</option>
              <option value="status">Situação</option>
              <option value="monthly_value">Valor Mensal</option>
            </select>
            <button
              onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
              className="px-2 py-1.5 border border-gray-300 rounded-lg text-xs hover:bg-gray-50 transition-colors"
              title={`Ordenação ${sortOrder === 'asc' ? 'crescente' : 'decrescente'}`}
            >
              {sortOrder === 'asc' ? '↑' : '↓'}
            </button>
          </div>

          <div className="h-6 w-px bg-gray-300"></div>

          {/* Status Filter */}
          <div className="flex items-center gap-2">
            <Filter className="w-3.5 h-3.5 text-gray-500" />
            <select
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="px-2 py-1.5 border border-gray-300 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-green-500"
            >
              <option value="all">Todas</option>
              <option value="SQL">SQL</option>
              <option value="Proposta">Proposta</option>
              <option value="Negociação">Negociação</option>
              <option value="Análise de contrato">Análise de contrato</option>
              <option value="Fechado">Fechado</option>
              <option value="Perdido">Perdido</option>
            </select>
          </div>

          <div className="h-6 w-px bg-gray-300"></div>

          {/* Empresa Filter */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-gray-500">Empresa</span>
            <select
              value={empresaFilter}
              onChange={(e) => setEmpresaFilter(e.target.value)}
              className="px-2 py-1.5 border border-gray-300 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-green-500"
            >
              <option value="all">Todas</option>
              {EMPRESA_OPTIONS.map(opt => (
                <option key={opt} value={opt}>{opt}</option>
              ))}
            </select>
          </div>

          <div className="h-6 w-px bg-gray-300"></div>

          {/* Month Filter */}
          <div className="relative flex items-center gap-2">
            <Calendar className="w-3.5 h-3.5 text-gray-500" />
            <div className="relative">
              <button
                onClick={() => setShowMonthDropdown(!showMonthDropdown)}
                className="px-2 py-1.5 border border-gray-300 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-green-500 min-w-[140px] bg-white flex items-center justify-between gap-2"
              >
                <span className="truncate">
                  {selectedMonths.includes('all') || selectedMonths.length === 0
                    ? 'Todos os meses'
                    : selectedMonths.length === 1
                    ? formatMonthLabel(selectedMonths[0])
                    : `${selectedMonths.length} meses`
                  }
                </span>
                <ChevronDown className={`w-3 h-3 flex-shrink-0 transition-transform ${showMonthDropdown ? 'rotate-180' : ''}`} />
              </button>

              {showMonthDropdown && (
                <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-gray-300 rounded-lg shadow-lg z-10 max-h-60 overflow-y-auto">
                  {/* Todos os meses option */}
                  <label className="flex items-center px-3 py-2 hover:bg-gray-50 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={selectedMonths.includes('all') || selectedMonths.length === availableMonths.length}
                      onChange={() => handleMonthToggle('all')}
                      className="mr-3 rounded border-gray-300 text-green-600 focus:ring-green-500"
                    />
                    <Calendar className="w-4 h-4 mr-2 text-gray-400" />
                    <span className="text-sm">Todos os meses</span>
                    {(selectedMonths.includes('all') || selectedMonths.length === availableMonths.length) && (
                      <Check className="w-4 h-4 ml-auto text-green-600" />
                    )}
                  </label>

                  <div className="border-t border-gray-200"></div>

                  {/* Individual months */}
                  {availableMonths.map(monthKey => (
                    <label key={monthKey} className="flex items-center px-3 py-2 hover:bg-gray-50 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={selectedMonths.includes('all') || selectedMonths.includes(monthKey)}
                        onChange={() => handleMonthToggle(monthKey)}
                        className="mr-3 rounded border-gray-300 text-green-600 focus:ring-green-500"
                      />
                      <span className="text-sm flex-1">{formatMonthLabel(monthKey)}</span>
                      {(selectedMonths.includes('all') || selectedMonths.includes(monthKey)) && (
                        <Check className="w-4 h-4 text-green-600" />
                      )}
                    </label>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="h-6 w-px bg-gray-300"></div>

          {/* Resumo das Propostas Button */}
          <button
            onClick={() => setShowResumoModal(true)}
            className="flex items-center gap-2 px-3 py-1.5 bg-blue-600 text-white rounded-lg text-xs hover:bg-blue-700 transition-colors"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Resumo das Propostas</span>
          </button>
        </div>

        {/* Filter Summary - Compact */}
        <div className="text-xs text-gray-500">
          Mostrando {filteredProposals.length} de {proposals.length} propostas • Ano: {selectedYear}
        </div>
      </div>
      {/* Click outside to close dropdown */}
      {showMonthDropdown && (
        <div 
          className="fixed inset-0 z-5" 
          onClick={() => setShowMonthDropdown(false)}
        ></div>
      )}

      {/* Proposals View */}
      {viewMode === 'list' ? (
        <div className="space-y-4">
          {/* Cards das propostas */}
          <div className="grid grid-cols-1 gap-4">
            {filteredProposals.map((proposal) => (
              <ProposalCard
                key={proposal.id}
                proposal={proposal}
                onUpdateProbability={canEditProposals ? handleUpdateProbability : undefined}
                onUpdateProposal={canEditProposals ? handleUpdateProposal : undefined}
                onRefreshData={refetch}
                readOnly={!canEditProposals}
              />
            ))}

            {filteredProposals.length === 0 && (
              <div className="text-center py-12">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Search className="w-8 h-8 text-gray-400" />
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-2">
                  {searchTerm ? 'Nenhuma proposta encontrada' : 'Nenhuma proposta'}
                </h3>
                <p className="text-gray-500">
                  {searchTerm
                    ? `Não encontramos propostas com "${searchTerm}". Tente outro termo de busca.`
                    : 'Clique em "Nova Proposta" para começar.'
                  }
                </p>
                {searchTerm && (
                  <button
                    onClick={() => setSearchTerm('')}
                    className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    Limpar Busca
                  </button>
                )}
              </div>
            )}
          </div>
        </div>
      ) : (
        <ProposalKanban
          proposals={filteredProposals}
          onMoveProposal={canEditProposals ? handleMoveProposal : () => {}}
          onViewDetails={(proposal) => setSelectedProposal(proposal)}
          readOnly={!canEditProposals}
        />
      )}

      {/* Proposal Form Modal */}
      {showForm && canEditProposals && (
        <ProposalForm
          onSubmit={handleAddProposal}
          onCancel={() => setShowForm(false)}
        />
      )}

      {/* Proposal Details Modal */}
      {selectedProposal && (
        <ProposalDetails
          proposal={selectedProposal}
          onClose={() => setSelectedProposal(null)}
          onUpdateProbability={canEditProposals ? handleUpdateProbability : undefined}
          onUpdateProposal={canEditProposals ? handleUpdateProposal : undefined}
          readOnly={!canEditProposals}
        />
      )}

      {/* Resumo das Propostas Modal */}
      {showResumoModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-6xl w-full max-h-[90vh] overflow-hidden flex flex-col">
            {/* Header */}
            <div className="p-4 border-b border-gray-200 flex items-center justify-between bg-gradient-to-r from-blue-50 to-blue-100">
              <div className="flex items-center gap-3">
                <FileText className="w-5 h-5 text-blue-600" />
                <h2 className="text-lg font-bold text-gray-800">Resumo das Propostas Ativas</h2>
              </div>
              <button
                onClick={() => setShowResumoModal(false)}
                className="text-gray-500 hover:text-gray-700 transition-colors"
              >
                <span className="text-2xl">&times;</span>
              </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-auto p-4">
              {/* Filtros */}
              <div className="mb-4 p-3 bg-gray-50 border border-gray-200 rounded-lg">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-gray-700 mb-1">Empresa</label>
                    <select
                      value={resumoEmpresa}
                      onChange={(e) => setResumoEmpresa(e.target.value)}
                      className="w-full px-2 py-1.5 border border-gray-300 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 bg-white"
                    >
                      <option value="all">Todas</option>
                      {resumoEmpresasDisponiveis.map(emp => (
                        <option key={emp} value={emp}>{emp}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-gray-700 mb-1">Data Inclusão (inicial)</label>
                    <input
                      type="date"
                      value={resumoDataInicial}
                      onChange={(e) => setResumoDataInicial(e.target.value)}
                      className="w-full px-2 py-1.5 border border-gray-300 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 bg-white"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-gray-700 mb-1">Data Inclusão (final)</label>
                    <input
                      type="date"
                      value={resumoDataFinal}
                      onChange={(e) => setResumoDataFinal(e.target.value)}
                      className="w-full px-2 py-1.5 border border-gray-300 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 bg-white"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-gray-700 mb-1">Status</label>
                    <select
                      value={resumoStatus}
                      onChange={(e) => setResumoStatus(e.target.value)}
                      className="w-full px-2 py-1.5 border border-gray-300 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 bg-white"
                    >
                      <option value="all">Todos</option>
                      {ACTIVE_PROPOSAL_STATUSES.map(s => (
                        <option key={s} value={s}>{s}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-gray-700 mb-1">Probabilidade</label>
                    <select
                      value={resumoProbabilidade}
                      onChange={(e) => setResumoProbabilidade(e.target.value as any)}
                      className="w-full px-2 py-1.5 border border-gray-300 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 bg-white"
                    >
                      <option value="all">Todas</option>
                      <option value="nao_avaliada">Não avaliada</option>
                      <option value="baixa">Baixa</option>
                      <option value="media">Média</option>
                      <option value="alta">Alta</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-gray-700 mb-1">Valor mensal (de)</label>
                    <input
                      type="number"
                      inputMode="decimal"
                      step="0.01"
                      value={resumoValorMin}
                      onChange={(e) => setResumoValorMin(e.target.value)}
                      placeholder="0,00"
                      className="w-full px-2 py-1.5 border border-gray-300 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 bg-white"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-gray-700 mb-1">Valor mensal (até)</label>
                    <input
                      type="number"
                      inputMode="decimal"
                      step="0.01"
                      value={resumoValorMax}
                      onChange={(e) => setResumoValorMax(e.target.value)}
                      placeholder="0,00"
                      className="w-full px-2 py-1.5 border border-gray-300 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 bg-white"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-gray-700 mb-1">Margem (de)</label>
                    <input
                      type="number"
                      inputMode="decimal"
                      step="0.01"
                      value={resumoMargemMin}
                      onChange={(e) => setResumoMargemMin(e.target.value)}
                      placeholder="0"
                      className="w-full px-2 py-1.5 border border-gray-300 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 bg-white"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-gray-700 mb-1">Margem (até)</label>
                    <input
                      type="number"
                      inputMode="decimal"
                      step="0.01"
                      value={resumoMargemMax}
                      onChange={(e) => setResumoMargemMax(e.target.value)}
                      placeholder="0"
                      className="w-full px-2 py-1.5 border border-gray-300 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 bg-white"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-gray-700 mb-1">Cidade</label>
                    <select
                      value={resumoCidade}
                      onChange={(e) => setResumoCidade(e.target.value)}
                      className="w-full px-2 py-1.5 border border-gray-300 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 bg-white"
                    >
                      <option value="all">Todas</option>
                      {resumoCidadesDisponiveis.map(c => (
                        <option key={c} value={c}>{c}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="mt-2 text-[11px] text-gray-500">
                  Mostrando <strong>{resumoPropostasFiltradas.length}</strong> propostas ativas após filtros
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="bg-gray-50 border-b border-gray-200">
                      <th className="px-3 py-2 text-left font-semibold text-gray-700">Cliente</th>
                      <th className="px-3 py-2 text-left font-semibold text-gray-700">Data Inclusão</th>
                      <th className="px-3 py-2 text-left font-semibold text-gray-700">Status</th>
                      <th className="px-3 py-2 text-left font-semibold text-gray-700">Probabilidade</th>
                      <th className="px-3 py-2 text-right font-semibold text-gray-700">Valor Mensal</th>
                      <th className="px-3 py-2 text-right font-semibold text-gray-700">Margem</th>
                      <th className="px-3 py-2 text-left font-semibold text-gray-700">Cidade</th>
                    </tr>
                  </thead>
                  <tbody>
                    {resumoPropostasFiltradas.map((proposal, index) => {
                        // Calcular o score total (soma dos 8 scores)
                        const totalScore = proposal.probabilityScores
                          ? (
                              proposal.probabilityScores.economicBuyer +
                              proposal.probabilityScores.metrics +
                              proposal.probabilityScores.decisionCriteria +
                              proposal.probabilityScores.decisionProcess +
                              proposal.probabilityScores.identifyPain +
                              proposal.probabilityScores.champion +
                              proposal.probabilityScores.competition +
                              proposal.probabilityScores.engagement
                            )
                          : 0;

                        // Determinar o label e cor da probabilidade
                        let probabilityLabel = 'Não avaliada';
                        let probabilityColor = 'bg-gray-100 text-gray-500 border border-gray-300';

                        if (totalScore > 0) {
                          if (totalScore < 12) {
                            probabilityLabel = 'Baixa';
                            probabilityColor = 'bg-red-50 text-red-700 border border-red-200';
                          } else if (totalScore <= 18) {
                            probabilityLabel = 'Média';
                            probabilityColor = 'bg-yellow-50 text-yellow-700 border border-yellow-200';
                          } else {
                            probabilityLabel = 'Alta';
                            probabilityColor = 'bg-green-50 text-green-700 border border-green-200';
                          }
                        }

                        const statusColors = {
                          'SQL': 'bg-cyan-100 text-cyan-800',
                          'Proposta': 'bg-blue-100 text-blue-800',
                          'Negociação': 'bg-yellow-100 text-yellow-800',
                          'Análise de contrato': 'bg-purple-100 text-purple-800'
                        };

                        return (
                          <tr key={proposal.id} className={`border-b border-gray-100 hover:bg-gray-50 ${index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}`}>
                            <td className="px-3 py-2 text-gray-900 font-medium">{proposal.client}</td>
                            <td className="px-3 py-2 text-gray-600">
                              {new Date(proposal.createdAt).toLocaleDateString('pt-BR')}
                            </td>
                            <td className="px-3 py-2">
                              <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${statusColors[proposal.status] || 'bg-gray-100 text-gray-800'}`}>
                                {proposal.status}
                              </span>
                            </td>
                            <td className="px-3 py-2">
                              <span className={`px-3 py-1 rounded-full text-xs font-medium ${probabilityColor}`}>
                                {probabilityLabel}
                              </span>
                            </td>
                            <td className="px-3 py-2 text-right font-medium text-gray-900">
                              {formatCurrency(proposal.monthlyValue)}
                            </td>
                            <td className="px-3 py-2 text-right font-medium text-blue-600">
                              {proposal.margemPercentual ? `${proposal.margemPercentual.toFixed(2)}%` : '-'}
                            </td>
                            <td className="px-3 py-2 text-gray-600">
                              {proposal.cidade || '-'}
                            </td>
                          </tr>
                        );
                      })}
                  </tbody>
                </table>

                {resumoPropostasFiltradas.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    <FileText className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                    <p>Nenhuma proposta encontrada com os filtros aplicados</p>
                  </div>
                )}
              </div>
            </div>

            {/* Footer com resumo */}
            <div className="p-4 border-t border-gray-200 bg-gray-50">
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-600">
                  Total: <strong>{resumoPropostasFiltradas.length}</strong> propostas ativas
                </span>
                <span className="text-gray-600">
                  Valor total: <strong className="text-blue-600">
                    {formatCurrency(resumoPropostasFiltradas.reduce((sum, p) => sum + p.monthlyValue, 0))}
                  </strong>/mês
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
});